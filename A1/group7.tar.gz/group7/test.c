void main(){
    string a;
    a="";
}
